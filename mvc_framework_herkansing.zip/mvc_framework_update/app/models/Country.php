<?php
  class Country {
    private $db;

    public function __construct() {
      $this->db = new Database();
    }

    public function getCountries() {
      $this->db->query("SELECT * FROM `countries`;");

      $result = $this->db->resultSet();

      return $result;
    }
    public function getSingleCountry($id){
      $this->db->query("SELECT * FROM `countries` WHERE id = :id;");
      $this->db->bind(':id, $id, PDO::PARAM_INT');
      var_dump($this->db->single());
    }
  }

?>