<?php
  class Rollercoaster {
    private $db;

    public function __construct() {
      $this->db = new Database();
    }

    public function getRollercoaster() {
      $this->db->query("SELECT * FROM `Rollercoaster`;");

      $result = $this->db->resultSet();

      return $result;
    }
    public function getSingleRollercoaster($id){
      $this->db->query("SELECT * FROM `Rollercoaster` WHERE id = :id;");
      $this->db->bind(':id, $id, PDO::PARAM_INT');
      var_dump($this->db->single());
    }
  }

?>