<?php echo $data["title"]; ?>

<table>
  <thead>
    <th>id</th>
    <th>nameRollercoaster</th>
    <th>nameAmusementpark</th>
    <th>country</th>
    <th>topspeed</th>
    <th>height</th>
  </thead>
  <tbody>
    <?=$data['countries']?>
  </tbody>
</table>
<a href="<?=URLROOT;?>/homepages/index">terug</a>

