<?php
class Countries extends Controller {

  public function __construct() {
    $this->countriesModel = $this->model('Country');
  }

  public function index() {
    /**
     * Haal via de method getFruits() uit de model Fruit de records op
     * uit de database
     */
    $countries = $this->countriesModel->getCountries();

    /**
     * Maak de inhoud voor de tbody in de view
     */
    $rows = '';
    foreach ($countries as $value){
      $rows .= "<tr>
                  <td>$value->id</td>
                  <td>" . htmlentities($value->nameRollercoaster, ENT_QUOTES, 'ISO-8859-1') . "</td>
                  <td>" . htmlentities($value->nameAmusementpark, ENT_QUOTES, 'ISO-8859-1') . "</td>
                  <td>" . htmlentities($value->country, ENT_QUOTES, 'ISO-8859-1') . "</td>
                  <td>" . number_format($value->topspeed, 0, ',', '.') . "</td>
                  <td>" . htmlentities($value->height, ENT_QUOTES, 'ISO-8859-1') . "</td>
                </tr>";
    }


    $data = [
      'title' => '<h1>De 5 snelste achtbanen van europa</h1>',
      'countries' => $rows
    ];
    $this->view('countries/index', $data);
  }

  public function update($id) {
    //var_dump($id);exit();
    $this->countriesModel->getSingleCountry($id);
  }
}

?>