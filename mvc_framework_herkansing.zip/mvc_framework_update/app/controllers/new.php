<?php
class new extends Controller {

  public function __construct() {
    $this->countriesModel = $this->model('users');
  }

  public function index() {
    /**
     * Haal via de method getFruits() uit de model Fruit de records op
     * uit de database
     */
    $countries = $this->countriesModel->getUsers();

    /**
     * Maak de inhoud voor de tbody in de view
     */
    $rows = '';
    foreach ($countries as $value){
      $rows .= "<tr>
                  <td>$value->id</td>
                  <td>" . htmlentities($value->name, ENT_QUOTES, 'ISO-8859-1') . "</td>
                  <td>" . htmlentities($value->color, ENT_QUOTES, 'ISO-8859-1') . "</td>
                  <td>" . htmlentities($value->price, ENT_QUOTES, 'ISO-8859-1') . "</td>
                  <td>" . number_format($value->population, 0, ',', '.') . "</td>
                  <td><a href='" . URLROOT ."/countries/update/$value->id'>update</a></td>
                  <td><a href='" . URLROOT ."/countries/delete/$value->id'>delete</a></td>
                </tr>";
    }


    $data = [
      'title' => '<h1>Landenoverzicht</h1>',
      'countries' => $rows
    ];
    $this->view('countries/index', $data);
  }

  public function update($id) {
    //var_dump($id);exit();
    $this->countriesModel->getSingleCountry($id);
  }
}

?>